import fs from 'fs';
import path from 'path';
import os from 'os';

// =====================
// Config loading
// =====================

interface GeminiConfig {
  baseUrl?: string;
  apiKey?: string;
  model?: string;
}

function loadConfig(): GeminiConfig | null {
  const homeDir = os.homedir();
  const candidates = [
    path.join(process.cwd(), '.z-ai-config'),
    path.join(homeDir, '.z-ai-config'),
    '/etc/.z-ai-config',
  ];
  for (const p of candidates) {
    try {
      if (fs.existsSync(p)) {
        const raw = fs.readFileSync(p, 'utf8');
        const cfg = JSON.parse(raw);
        if (cfg.apiKey) return cfg;
      }
    } catch {
      /* skip malformed */
    }
  }
  return null;
}

const CONFIG = loadConfig();
const GEMINI_MODEL = CONFIG?.model || 'gemini-2.5-flash';
const GEMINI_NATIVE_BASE = 'https://generativelanguage.googleapis.com/v1beta';

if (CONFIG?.apiKey) {
  console.log('[AI] Provider: Gemini | model:', GEMINI_MODEL);
} else {
  console.warn('[AI] No .z-ai-config found — AI features will fail.');
}

function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

// =====================
// LLM
// =====================

export interface LLMMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export interface LLMOptions {
  /** Enable Google Search grounding for real-time data */
  useSearch?: boolean;
}

/**
 * Call Gemini's native generateContent API.
 * Pass { useSearch: true } to enable Google Search grounding for real-time data.
 */
export async function callLLM(
  messages: LLMMessage[],
  maxRetries: number = 2,
  options?: LLMOptions
): Promise<string> {
  if (!CONFIG?.apiKey) {
    throw new Error('Gemini config missing apiKey in .z-ai-config');
  }

  const url = `${GEMINI_NATIVE_BASE}/models/${GEMINI_MODEL}:generateContent?key=${CONFIG.apiKey}`;

  // Split system vs chat messages
  const systemText = messages
    .filter((m) => m.role === 'system')
    .map((m) => m.content)
    .join('\n\n');
  const chatMessages = messages.filter((m) => m.role !== 'system');

  const payload: Record<string, unknown> = {
    contents: chatMessages.map((m) => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }],
    })),
    generationConfig: {
      temperature: 0.7,
      thinkingConfig: { thinkingBudget: 0 },
    },
  };
  if (systemText) {
    payload.systemInstruction = { parts: [{ text: systemText }] };
  }
  if (options?.useSearch) {
    payload.tools = [{ google_search: {} }];
  }

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(60000),
      });

      if (!res.ok) {
        const errText = await res.text();
        const is429 = res.status === 429;
        if (attempt < maxRetries && (is429 || res.status >= 500)) {
          const delay = is429 ? 6000 * (attempt + 1) : 2000;
          console.warn(`[LLM/Gemini] ${res.status} (attempt ${attempt + 1}), retry in ${delay}ms`);
          await sleep(delay);
          continue;
        }
        throw new Error(`Gemini LLM ${res.status}: ${errText.slice(0, 400)}`);
      }

      const data = await res.json();
      const parts = data?.candidates?.[0]?.content?.parts;
      if (!Array.isArray(parts)) {
        throw new Error('Gemini returned no content parts');
      }
      const text = parts
        .map((p: { text?: string }) => p.text || '')
        .join('')
        .trim();
      if (!text) throw new Error('Gemini returned empty text');
      return text;
    } catch (error) {
      if (attempt < maxRetries) {
        await sleep(1500 * (attempt + 1));
        continue;
      }
      throw error;
    }
  }
  throw new Error('Gemini LLM call failed after retries');
}

// =====================
// Web Search (via Gemini Google Search grounding)
// =====================

export interface SearchResult {
  url: string;
  name: string;
  snippet: string;
  host_name: string;
  rank: number;
  date?: string;
  favicon?: string;
}

/**
 * Web search via Gemini Google Search grounding.
 * Uses the same Gemini API key — no separate search API needed.
 */
export async function webSearch(
  query: string,
  numResults: number = 10
): Promise<SearchResult[]> {
  if (!CONFIG?.apiKey) {
    console.error('[WebSearch] No API key configured');
    return [];
  }

  const url = `${GEMINI_NATIVE_BASE}/models/${GEMINI_MODEL}:generateContent?key=${CONFIG.apiKey}`;

  const payload = {
    contents: [
      {
        parts: [
          {
            text: `Search the web for: ${query}\n\nList the most relevant web pages found. For each page, include its URL, title, and a brief snippet of what the page contains.`,
          },
        ],
      },
    ],
    tools: [{ google_search: {} }],
    generationConfig: {
      temperature: 0,
      thinkingConfig: { thinkingBudget: 0 },
    },
  };

  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(45000),
    });

    if (!res.ok) {
      const errText = await res.text();
      console.error(`[WebSearch] HTTP ${res.status}: ${errText.slice(0, 300)}`);
      return [];
    }

    const data = await res.json();
    const candidate = data?.candidates?.[0];
    if (!candidate) {
      console.warn('[WebSearch] No candidates in response');
      return [];
    }

    // Extract grounding chunks (URLs + titles)
    const groundingMetadata = candidate.groundingMetadata || {};
    const chunks: Array<{ web?: { uri?: string; title?: string } }> =
      groundingMetadata.groundingChunks || [];

    // Extract grounding supports (snippets associated with chunk indices)
    const supports: Array<{
      groundingChunkIndices?: number[];
      segment?: { text?: string };
    }> = groundingMetadata.groundingSupports || [];

    // Build snippet map: chunk index → concatenated snippet text
    const snippetMap = new Map<number, string>();
    for (const support of supports) {
      const indices = support.groundingChunkIndices || [];
      const text = support.segment?.text || '';
      for (const idx of indices) {
        const existing = snippetMap.get(idx) || '';
        snippetMap.set(idx, existing ? existing + ' ' + text : text);
      }
    }

    // Also capture the model's text response — it often summarizes prices
    const modelText = (candidate.content?.parts || [])
      .map((p: { text?: string }) => p.text || '')
      .join(' ')
      .trim();

    const results: SearchResult[] = [];
    for (let i = 0; i < chunks.length && results.length < numResults; i++) {
      const web = chunks[i]?.web;
      if (!web?.uri) continue;
      let host = '';
      try {
        host = new URL(web.uri).hostname.replace(/^www\./, '');
      } catch {
        /* skip */
      }
      results.push({
        url: web.uri,
        name: web.title || host || '',
        snippet: (snippetMap.get(i) || '').slice(0, 500),
        host_name: host,
        rank: i,
      });
    }

    // Add the model's text response as a synthetic result so the LLM
    // snippet extraction phase can parse prices from it.
    if (modelText && modelText.length > 20) {
      results.push({
        url: 'https://google-search-grounding.synthetic',
        name: `AI Search Summary: ${query.slice(0, 60)}`,
        snippet: modelText.slice(0, 1000),
        host_name: 'google.com',
        rank: results.length,
      });
    }

    console.log(`[WebSearch] "${query.slice(0, 50)}..." → ${results.length} results${modelText ? ' (+AI summary)' : ''}`);
    return results;
  } catch (e) {
    console.error('[WebSearch] Failed:', e instanceof Error ? e.message : e);
    return [];
  }
}

// =====================
// Page Reader (direct HTTP fetch)
// =====================

export interface WebPage {
  title: string;
  url: string;
  html: string;
  text: string;
  publishedTime?: string;
}

/**
 * Direct page fetch with browser-like headers.
 * Fetches HTML, strips scripts/styles/nav/footer/tags, returns clean text.
 */
export async function readWebPage(url: string): Promise<WebPage | null> {
  try {
    const res = await fetch(url, {
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
        Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Accept-Encoding': 'gzip, deflate, br',
      },
      redirect: 'follow',
      signal: AbortSignal.timeout(15000),
    });

    if (!res.ok) {
      console.warn(`[PageReader] HTTP ${res.status}: ${url.slice(0, 60)}`);
      return null;
    }

    const contentType = res.headers.get('content-type') || '';
    if (
      !contentType.includes('text/html') &&
      !contentType.includes('text/plain') &&
      !contentType.includes('application/xhtml')
    ) {
      console.warn(`[PageReader] Non-HTML (${contentType.slice(0, 30)}): ${url.slice(0, 60)}`);
      return null;
    }

    const html = await res.text();
    if (html.length < 200) {
      console.warn(`[PageReader] Too short: ${url.slice(0, 60)}`);
      return null;
    }

    // Extract title
    let title = '';
    const titleMatch = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
    if (titleMatch) {
      title = titleMatch[1]
        .replace(/&amp;/g, '&')
        .replace(/&quot;/g, '"')
        .replace(/&#x27;/g, "'")
        .trim();
    }

    const text = html
      .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
      .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
      .replace(/<noscript[^>]*>[\s\S]*?<\/noscript>/gi, '')
      .replace(/<header[^>]*>[\s\S]*?<\/header>/gi, '')
      .replace(/<footer[^>]*>[\s\S]*?<\/footer>/gi, '')
      .replace(/<nav[^>]*>[\s\S]*?<\/nav>/gi, '')
      .replace(/<[^>]*>/g, ' ')
      .replace(/&nbsp;/g, ' ')
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"')
      .replace(/&#x27;/g, "'")
      .replace(/&rsquo;/g, "'")
      .replace(/&lsquo;/g, "'")
      .replace(/&ldquo;/g, '"')
      .replace(/&rdquo;/g, '"')
      .replace(/&mdash;/g, '—')
      .replace(/&ndash;/g, '–')
      .replace(/&hellip;/g, '…')
      .replace(/\s+/g, ' ')
      .trim();

    if (text.length < 100) {
      console.warn(`[PageReader] Text too short (${text.length}): ${url.slice(0, 60)}`);
      return null;
    }

    return {
      title,
      url: res.url || url,
      html,
      text,
    };
  } catch (e) {
    console.warn(
      `[PageReader] Failed: ${url.slice(0, 60)} — ${e instanceof Error ? e.message : e}`
    );
    return null;
  }
}

// =====================
// JSON Parser
// =====================

export function parseJSONResponse<T>(text: string): T {
  let cleaned = text.trim();
  if (cleaned.startsWith('```json')) cleaned = cleaned.slice(7);
  else if (cleaned.startsWith('```')) cleaned = cleaned.slice(3);
  if (cleaned.endsWith('```')) cleaned = cleaned.slice(0, -3);
  cleaned = cleaned.trim();

  const objMatch = cleaned.match(/\{[\s\S]*\}/);
  if (objMatch) {
    try {
      return JSON.parse(objMatch[0]) as T;
    } catch {
      /* fall through */
    }
  }

  const arrMatch = cleaned.match(/\[[\s\S]*\]/);
  if (arrMatch) {
    try {
      return JSON.parse(arrMatch[0]) as T;
    } catch {
      /* fall through */
    }
  }

  return JSON.parse(cleaned) as T;
}
