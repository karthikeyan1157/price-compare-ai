import ZAI from 'z-ai-web-dev-sdk';

let _zai: Awaited<ReturnType<typeof ZAI.create>> | null = null;

export async function getZAI() {
  if (!_zai) {
    _zai = await ZAI.create();
  }
  return _zai;
}

// =====================
// Global Rate Limiter
// =====================
// The ZAI SDK has aggressive rate limits. We must be very conservative.
// All SDK function calls go through a single global queue.

let lastCallTime = 0;
const MIN_CALL_GAP = 2500; // 2.5 seconds minimum between ANY SDK calls

async function globalRateLimit() {
  const now = Date.now();
  const elapsed = now - lastCallTime;
  if (elapsed < MIN_CALL_GAP) {
    const wait = MIN_CALL_GAP - elapsed + 500;
    console.log(`[RateLimit] Waiting ${wait}ms between SDK calls...`);
    await new Promise(r => setTimeout(r, wait));
  }
  lastCallTime = Date.now();
}

function sleep(ms: number): Promise<void> {
  return new Promise(r => setTimeout(r, ms));
}

// =====================
// LLM
// =====================

export interface LLMMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export async function callLLM(
  messages: LLMMessage[],
  maxRetries: number = 2
): Promise<string> {
  await globalRateLimit();

  const zai = await getZAI();

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      const completion = await zai.chat.completions.create({
        messages: messages.map(m => ({
          role: m.role as 'user' | 'assistant',
          content: m.content,
        })),
        thinking: { type: 'disabled' },
      });

      const content = completion.choices[0]?.message?.content;
      if (!content) throw new Error('LLM returned empty content');
      return content;
    } catch (error) {
      const is429 = String(error).includes('429');
      if (attempt < maxRetries) {
        const delay = is429 ? 5000 * (attempt + 1) : 1000;
        console.warn(`[LLM] Attempt ${attempt + 1} failed${is429 ? ' (429)' : ''}, retry in ${delay}ms`);
        await sleep(delay);
        await globalRateLimit();
      } else {
        throw error;
      }
    }
  }

  throw new Error('LLM call failed after retries');
}

// =====================
// Web Search
// =====================

export async function webSearch(
  query: string,
  numResults: number = 10
): Promise<Array<{
  url: string;
  name: string;
  snippet: string;
  host_name: string;
  rank: number;
  date?: string;
  favicon?: string;
}>> {
  await globalRateLimit();

  const zai = await getZAI();
  const maxRetries = 3;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      const results = await zai.functions.invoke('web_search', {
        query,
        num: numResults,
      });
      return Array.isArray(results) ? results : [];
    } catch (error) {
      const is429 = String(error).includes('429');
      if (is429 && attempt < maxRetries) {
        const delay = 6000 * (attempt + 1);
        console.warn(`[WebSearch] 429, waiting ${delay}ms (attempt ${attempt + 1})...`);
        await sleep(delay);
        await globalRateLimit();
        continue;
      }
      if (attempt < maxRetries) {
        await sleep(2000);
        await globalRateLimit();
        continue;
      }
      console.error('[WebSearch] All retries failed');
      return [];
    }
  }

  return [];
}

// =====================
// Page Reader
// =====================

export async function readWebPage(url: string): Promise<{
  title: string;
  url: string;
  html: string;
  text: string;
  publishedTime?: string;
} | null> {
  await globalRateLimit();

  const zai = await getZAI();
  const maxRetries = 2;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      const result = await zai.functions.invoke('page_reader', { url });
      const data = result?.data || result;
      const html = data?.html || '';

      const text = html
        .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
        .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
        .replace(/<[^>]*>/g, ' ')
        .replace(/&nbsp;/g, ' ')
        .replace(/&amp;/g, '&')
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&quot;/g, '"')
        .replace(/\s+/g, ' ')
        .trim();

      if (text.length < 100) {
        console.warn(`[PageReader] Too short (${text.length} chars): ${url}`);
        return null;
      }

      return {
        title: data?.title || '',
        url: data?.url || url,
        html,
        text,
        publishedTime: data?.publishedTime,
      };
    } catch (error) {
      const is429 = String(error).includes('429');
      if (is429 && attempt < maxRetries) {
        const delay = 8000 * (attempt + 1);
        console.warn(`[PageReader] 429, waiting ${delay}ms (attempt ${attempt + 1})...`);
        await sleep(delay);
        await globalRateLimit();
        continue;
      }
      if (attempt < maxRetries) {
        await sleep(3000);
        await globalRateLimit();
        continue;
      }
      console.error(`[PageReader] Failed: ${url}`);
      return null;
    }
  }

  return null;
}

// =====================
// JSON Parser
// =====================

export function parseJSONResponse<T>(text: string): T {
  let cleaned = text.trim();
  if (cleaned.startsWith('```json')) cleaned = cleaned.slice(7);
  else if (cleaned.startsWith('```')) cleaned = cleaned.slice(3);
  if (cleaned.endsWith('```')) cleaned = cleaned.slice(0, -3);
  cleaned = cleaned.trim();

  // Try to find JSON in the response
  const objMatch = cleaned.match(/\{[\s\S]*\}/);
  if (objMatch) {
    try { return JSON.parse(objMatch[0]) as T; } catch { /* fall through */ }
  }

  const arrMatch = cleaned.match(/\[[\s\S]*\]/);
  if (arrMatch) {
    try { return JSON.parse(arrMatch[0]) as T; } catch { /* fall through */ }
  }

  return JSON.parse(cleaned) as T;
}