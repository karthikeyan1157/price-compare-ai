'use client';

import { motion } from 'framer-motion';
import {
  Sparkles,
  Search,
  BarChart3,
  Ticket,
  MessageSquare,
  ShieldCheck,
  History,
  Store,
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

const features = [
  {
    icon: Sparkles,
    title: 'AI Price Comparison',
    description:
      'Compare prices across 20+ stores instantly with AI-powered analysis for the best deals.',
  },
  {
    icon: Search,
    title: 'Smart Search',
    description:
      'Natural language search that understands what you need — find any product in seconds.',
  },
  {
    icon: BarChart3,
    title: 'Price Prediction',
    description:
      'AI predicts future price movements so you know the best time to buy.',
  },
  {
    icon: Ticket,
    title: 'Coupon Finder',
    description:
      'Automatically discover applicable coupons, bank offers, and cashback deals.',
  },
  {
    icon: MessageSquare,
    title: 'Review Summary',
    description:
      'AI reads thousands of reviews and gives you a concise, honest summary.',
  },
  {
    icon: ShieldCheck,
    title: 'Fake Discount Detector',
    description:
      'Detect inflated MRP and fake discounts. Know if a deal is genuinely good.',
  },
  {
    icon: History,
    title: 'Price History Tracking',
    description:
      'Track 6-month price trends across all stores with detailed charts.',
  },
  {
    icon: Store,
    title: 'Multi-Store Support',
    description:
      'Compare across Amazon, Flipkart, Croma, Myntra, Apple Store, and 15+ more stores.',
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.08 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.4, ease: 'easeOut' },
  },
};

export default function FeaturesSection() {
  return (
    <section className="w-full py-16 sm:py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-50px' }}
          transition={{ duration: 0.5 }}
          className="mb-10 text-center sm:mb-14"
        >
          <h2 className="text-2xl font-bold sm:text-3xl">
            Everything You Need to{' '}
            <span className="text-primary">Save Money</span>
          </h2>
          <p className="mx-auto mt-3 max-w-xl text-sm text-muted-foreground sm:text-base">
            Powerful AI tools that help you make smarter shopping decisions and find the best deals
            across all major online stores.
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-50px' }}
          className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4"
        >
          {features.map((feature) => {
            const Icon = feature.icon;
            return (
              <motion.div key={feature.title} variants={itemVariants}>
                <Card className="group h-full border-border/50 bg-card transition-all duration-300 hover:border-primary/20 hover:shadow-md">
                  <CardContent className="p-5 sm:p-6">
                    <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 transition-colors group-hover:bg-primary/15">
                      <Icon className="h-5 w-5 text-primary" />
                    </div>
                    <h3 className="mb-1.5 text-sm font-semibold">{feature.title}</h3>
                    <p className="text-xs leading-relaxed text-muted-foreground sm:text-sm">
                      {feature.description}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}