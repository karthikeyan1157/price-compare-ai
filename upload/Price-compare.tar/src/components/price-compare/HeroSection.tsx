'use client';

import { Search, TrendingUp, Percent, Tag } from 'lucide-react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { useAppStore } from '@/store/app-store';
import { cn } from '@/lib/utils';
import { useState, useRef, useEffect } from 'react';

const floatingElements = [
  { icon: Tag, label: '₹12,999', x: '10%', y: '20%', delay: 0, size: 'md' },
  { icon: Percent, label: '-32%', x: '85%', y: '15%', delay: 0.5, size: 'sm' },
  { icon: TrendingUp, label: 'Best Deal', x: '75%', y: '70%', delay: 1, size: 'lg' },
  { icon: Percent, label: '-18%', x: '15%', y: '75%', delay: 1.5, size: 'sm' },
  { icon: Tag, label: '₹7,499', x: '90%', y: '45%', delay: 0.8, size: 'md' },
];

export default function HeroSection() {
  const {
    searchQuery,
    setSearchQuery,
    trendingSearches,
    isSearching,
    setIsSearching,
    setSearchResults,
    setView,
  } = useAppStore();

  const [isFocused, setIsFocused] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const timer = setTimeout(() => inputRef.current?.focus(), 500);
    return () => clearTimeout(timer);
  }, []);

  const handleSearch = () => {
    if (!searchQuery.trim() || isSearching) return;
    setIsSearching(true);
    setView('results');

    fetch(`/api/search?q=${encodeURIComponent(searchQuery.trim())}`)
      .then((res) => {
        if (!res.ok) {
          return res.json().then((d) => {
            throw new Error(d.error || 'Search failed');
          });
        }
        return res.json();
      })
      .then((data) => {
        if (data && data.error) {
          setSearchResults({ error: data.error } as any);
        } else {
          setSearchResults(data);
        }
      })
      .catch((err) => {
        const msg = err instanceof Error ? err.message : 'Search failed. Please try again.';
        setSearchResults({ error: msg } as any);
      })
      .finally(() => {
        setIsSearching(false);
      });
  };

  const handleTrendingClick = (query: string) => {
    setSearchQuery(query);
    setIsSearching(true);
    setView('results');

    fetch(`/api/search?q=${encodeURIComponent(query.trim())}`)
      .then((res) => {
        if (!res.ok) {
          return res.json().then((d) => {
            throw new Error(d.error || 'Search failed');
          });
        }
        return res.json();
      })
      .then((data) => {
        if (data && data.error) {
          setSearchResults({ error: data.error } as any);
        } else {
          setSearchResults(data);
        }
      })
      .catch((err) => {
        const msg = err instanceof Error ? err.message : 'Search failed. Please try again.';
        setSearchResults({ error: msg } as any);
      })
      .finally(() => {
        setIsSearching(false);
      });
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleSearch();
  };

  return (
    <section className="relative w-full overflow-hidden">
      {/* Animated gradient background */}
      <div
        className={cn(
          'animated-gradient absolute inset-0 opacity-30 dark:opacity-20',
        )}
        style={{
          background:
            'linear-gradient(135deg, oklch(0.85 0.08 155), oklch(0.80 0.12 145), oklch(0.90 0.06 160), oklch(0.85 0.10 150))',
        }}
      />

      {/* Floating elements */}
      {floatingElements.map((el, i) => (
        <motion.div
          key={i}
          className="pointer-events-none absolute hidden lg:block"
          style={{ left: el.x, top: el.y }}
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{
            opacity: [0.15, 0.3, 0.15],
            scale: [0.9, 1.05, 0.9],
            y: [0, -10, 0],
          }}
          transition={{
            duration: 4,
            delay: el.delay,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          <div
            className={cn(
              'flex items-center gap-1.5 rounded-full border border-primary/20 bg-background/60 px-3 py-1.5 shadow-sm backdrop-blur-sm',
              el.size === 'sm' && 'text-xs',
              el.size === 'md' && 'text-sm',
              el.size === 'lg' && 'text-base',
            )}
          >
            <el.icon className="h-3.5 w-3.5 text-primary" />
            <span className="font-semibold text-primary">{el.label}</span>
          </div>
        </motion.div>
      ))}

      {/* Content */}
      <div className="relative z-10 mx-auto max-w-4xl px-4 pb-12 pt-16 sm:px-6 sm:pt-24 lg:pt-28">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.1, duration: 0.5 }}
          >
            <Badge variant="secondary" className="mb-4 px-3 py-1 text-xs">
              AI-Powered Price Comparison
            </Badge>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            className="text-3xl font-bold tracking-tight sm:text-4xl lg:text-5xl xl:text-6xl"
          >
            Find the Best Prices
            <br />
            <span className="text-primary">Across All Stores</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.35, duration: 0.5 }}
            className="mx-auto mt-4 max-w-2xl text-base text-muted-foreground sm:text-lg"
          >
            Searches Google in real-time for live prices from Amazon, Flipkart, Croma and more
          </motion.p>
        </motion.div>

        {/* Search Bar */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.5 }}
          className="mx-auto mt-8 max-w-2xl"
        >
          <div
            className={cn(
              'relative rounded-2xl border bg-background shadow-lg transition-all duration-300',
              isFocused
                ? 'border-primary/50 shadow-primary/10 shadow-xl'
                : 'border-border/50',
            )}
          >
            <Search className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
            <Input
              ref={inputRef}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={handleKeyDown}
              onFocus={() => setIsFocused(true)}
              onBlur={() => setIsFocused(false)}
              placeholder='Search — e.g. "iPhone 16 128GB", "MacBook Air M4"...'
              className="h-12 rounded-2xl border-0 bg-transparent pl-12 pr-28 text-base shadow-none focus-visible:ring-0 sm:h-14 sm:text-lg"
            />
            <Button
              onClick={handleSearch}
              disabled={isSearching || !searchQuery.trim()}
              className="absolute right-2 top-1/2 h-9 -translate-y-1/2 rounded-xl bg-primary px-5 text-sm font-semibold text-primary-foreground hover:bg-primary/90 sm:h-10 sm:px-6"
            >
              {isSearching ? (
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ repeat: Infinity, duration: 1, ease: 'linear' }}
                  className="h-4 w-4 rounded-full border-2 border-primary-foreground/30 border-t-primary-foreground"
                />
              ) : (
                <>
                  <Search className="h-4 w-4" />
                  <span className="hidden sm:inline">Compare Prices</span>
                </>
              )}
            </Button>
          </div>
        </motion.div>

        {/* Trending Searches */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7, duration: 0.5 }}
          className="mt-6 text-center"
        >
          <p className="mb-3 text-xs font-medium text-muted-foreground sm:text-sm">
            <TrendingUp className="mr-1 inline h-3.5 w-3.5" />
            Try These Searches
          </p>
          <div className="flex flex-wrap items-center justify-center gap-2">
            {trendingSearches.slice(0, 6).map((trend, i) => (
              <motion.button
                key={trend.query}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.8 + i * 0.05, duration: 0.3 }}
                onClick={() => handleTrendingClick(trend.query)}
                className="rounded-full border border-border/60 bg-background/80 px-3 py-1.5 text-xs text-muted-foreground transition-colors hover:border-primary/40 hover:bg-primary/5 hover:text-primary sm:text-sm"
              >
                {trend.query}
              </motion.button>
            ))}
          </div>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1, duration: 0.5 }}
          className="mt-10 flex flex-wrap items-center justify-center gap-3 text-xs text-muted-foreground sm:gap-6 sm:text-sm"
        >
          {[
            { label: '20+ Stores', icon: '🏪' },
            { label: 'Real-Time Prices', icon: '⚡' },
            { label: 'AI-Powered', icon: '🤖' },
            { label: 'Live Google Search', icon: '🔍' },
          ].map((stat) => (
            <div key={stat.label} className="flex items-center gap-1.5">
              <span>{stat.icon}</span>
              <span className="font-medium">{stat.label}</span>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}