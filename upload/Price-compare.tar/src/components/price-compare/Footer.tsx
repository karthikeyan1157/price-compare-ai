'use client';

import { Tag, Github, Twitter, Linkedin, Mail } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import StoreLogo from './StoreLogo';

const storeList = [
  'Amazon',
  'Flipkart',
  'Apple',
  'Myntra',
  'Snapdeal',
  'Croma Retail',
  'Tata CLiQ Luxury',
  'Reliance Digital',
  'Paytm Mall',
];

const footerLinks = {
  About: [
    { label: 'About Us', href: '#' },
    { label: 'How It Works', href: '#' },
    { label: 'Blog', href: '#' },
    { label: 'Careers', href: '#' },
  ],
  Features: [
    { label: 'Price Comparison', href: '#' },
    { label: 'Price Prediction', href: '#' },
    { label: 'Coupon Finder', href: '#' },
    { label: 'Review Summary', href: '#' },
  ],
  Legal: [
    { label: 'Privacy Policy', href: '#' },
    { label: 'Terms of Service', href: '#' },
    { label: 'Disclaimer', href: '#' },
    { label: 'Contact Us', href: '#' },
  ],
};

const socialLinks = [
  { icon: Twitter, label: 'Twitter', href: '#' },
  { icon: Github, label: 'GitHub', href: '#' },
  { icon: Linkedin, label: 'LinkedIn', href: '#' },
  { icon: Mail, label: 'Email', href: '#' },
];

export default function Footer() {
  return (
    <footer className="mt-auto w-full border-t border-border/50 bg-primary text-primary-foreground">
      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 sm:py-14">
        {/* Store Logos Row */}
        <div className="mb-8">
          <p className="mb-3 text-xs font-medium uppercase tracking-wider text-primary-foreground/60">
            Supported Stores
          </p>
          <div className="flex flex-wrap items-center gap-3">
            {storeList.map((store) => (
              <div
                key={store}
                className="flex h-8 w-8 items-center justify-center rounded-full bg-primary-foreground/10 text-xs font-bold text-primary-foreground/80"
              >
                {store.charAt(0)}
              </div>
            ))}
          </div>
        </div>

        <Separator className="mb-8 bg-primary-foreground/10" />

        {/* Footer Columns */}
        <div className="grid grid-cols-2 gap-6 sm:grid-cols-4 sm:gap-8">
          {/* Brand */}
          <div className="col-span-2 sm:col-span-1">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary-foreground/20">
                <Tag className="h-4 w-4 text-primary-foreground" />
              </div>
              <span className="text-base font-bold">
                Price Compare <span className="text-primary-foreground/70">AI</span>
              </span>
            </div>
            <p className="mt-3 max-w-xs text-xs leading-relaxed text-primary-foreground/60">
              AI-powered price comparison platform helping millions of Indian shoppers find the
              best deals across all major online stores.
            </p>
          </div>

          {/* Link Columns */}
          {Object.entries(footerLinks).map(([title, links]) => (
            <div key={title}>
              <p className="mb-3 text-xs font-semibold uppercase tracking-wider text-primary-foreground/60">
                {title}
              </p>
              <ul className="space-y-2">
                {links.map((link) => (
                  <li key={link.label}>
                    <a
                      href={link.href}
                      className="text-xs text-primary-foreground/70 transition-colors hover:text-primary-foreground"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <Separator className="my-8 bg-primary-foreground/10" />

        {/* Bottom Row */}
        <div className="flex flex-col items-center justify-between gap-4 sm:flex-row">
          <p className="text-xs text-primary-foreground/50">
            © 2025 Price Compare AI. Powered by AI.
          </p>
          <div className="flex items-center gap-3">
            {socialLinks.map((social) => {
              const Icon = social.icon;
              return (
                <a
                  key={social.label}
                  href={social.href}
                  className="flex h-8 w-8 items-center justify-center rounded-lg text-primary-foreground/50 transition-colors hover:bg-primary-foreground/10 hover:text-primary-foreground"
                  aria-label={social.label}
                >
                  <Icon className="h-4 w-4" />
                </a>
              );
            })}
          </div>
        </div>
      </div>
    </footer>
  );
}