# Task 3 — Backend API Routes for Price Compare AI

**Agent**: Backend API Builder

## Summary
Built all 9 backend API routes for the Price Compare AI platform using Next.js 16 App Router route handlers, `z-ai-web-dev-sdk` for LLM + web search, and Prisma for database operations.

## Files Created

### Shared Helpers
- **`src/lib/zai.ts`** — ZAI SDK wrapper with singleton instance, retry logic (exponential backoff), web search, and JSON parsing utility
- **`src/lib/store-logos.ts`** — Store logo mapping using Clearbit Logo API for 20+ Indian e-commerce stores with fallback

### API Routes (9 total)
| Route | Methods | Purpose |
|-------|---------|---------|
| `/api/search` | POST | Core product search with web search + LLM, returns full `ProductSearchResult` |
| `/api/chat` | POST | AI Shopping Assistant with conversation history |
| `/api/price-history` | POST | Generate 180-day price history |
| `/api/coupons` | POST | Find applicable coupons/deals |
| `/api/recommend` | POST | Recommend similar products |
| `/api/review-summary` | POST | AI review summary via web search + LLM |
| `/api/fake-discount` | POST | Analyze if discounts are genuine |
| `/api/price-prediction` | POST | Predict future price movement |
| `/api/wishlist` | GET/POST/DELETE | Full CRUD for wishlist items |

### Key Design Decisions
- All routes: `runtime = 'nodejs'` for z-ai-web-dev-sdk compatibility
- Retry logic (2 retries, exponential backoff) on all LLM calls
- Non-critical DB ops (search history) don't fail the request
- Input validation with descriptive 400/404/409/500 error responses
- Zero lint errors in all new files